// script.js
document.addEventListener('DOMContentLoaded', function() {
    // Welcome Pop-up (You might want to use a library for more advanced pop-up features)
    setTimeout(function() {
        alert('¡Bienvenido a Urbaez Asesoría Contable y de Datos! Contáctanos para una consulta.');
    }, 3000); // Display after 3 seconds

    // Simple form validation (Enhance as needed)
    const contactForm = document.querySelector('.contact form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            let isValid = true;
            const nameInput = contactForm.querySelector('input[type="text"]');
            const emailInput = contactForm.querySelector('input[type="email"]');
            const messageTextarea = contactForm.querySelector('textarea');

            if (!nameInput.value.trim()) {
                alert('Por favor, ingrese su nombre.');
                isValid = false;
                nameInput.focus();
            } else if (!emailInput.value.trim()) {
                alert('Por favor, ingrese su correo electrónico.');
                isValid = false;
                emailInput.focus();
            } else if (!messageTextarea.value.trim()) {
                alert('Por favor, ingrese su mensaje.');
                isValid = false;
                messageTextarea.focus();
            }

            if (!isValid) {
                event.preventDefault(); // Prevent form submission if not valid
            } else {
                alert('Mensaje enviado. ¡Gracias!');
                // You would typically submit the form data using AJAX here.
            }
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});

